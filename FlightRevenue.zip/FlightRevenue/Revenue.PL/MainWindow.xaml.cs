﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Revenue.Entities;
using Revenue.Exceptions;
using Revenue.BL;
using Revenue.DAL;

namespace Revenue.PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
        }


        private void UpdateUI()
        {
            try
            {
                RevenueDAL revDAL = new RevenueDAL();
                IEnumerable<Revenues> rev = revDAL.SelectAllDAL(109);
                dgrev.ItemsSource = rev;
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            UpdateUI();
        }
    }
}
