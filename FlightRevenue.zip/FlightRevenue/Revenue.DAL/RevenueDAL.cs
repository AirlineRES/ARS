﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Revenue.Exceptions;
using System.Configuration;
using System.Data.SqlClient;
using Revenue.Entities;

namespace Revenue.DAL
{
    public class RevenueDAL
    {
        SqlConnection con = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public RevenueDAL()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["con1"].ConnectionString);

        }

        public IEnumerable<Revenues> SelectAllDAL(int FlightID)
        {
            List<Revenues> revList = new List<Revenues>();

            try
            {
                
                cmd = new SqlCommand("[airline].[USP_Rev2]", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@f_Id", FlightID);
               
                con.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        Revenues rev = new Revenues();
                        rev.TotalRevenue = Convert.ToInt32(dr[0]);
                        //rev.FareFirstClass = Convert.ToInt32(dr[1]);
                        //rev.FareEconomyClass = Convert.ToInt32(dr[2]);
                        //rev.NumberBusinessClass = Convert.ToInt32(dr[3]);
                        //rev.NumberFirstClass = Convert.ToInt32(dr[4]);
                        //rev.NumberEconomyClass = Convert.ToInt32(dr[5]);

                        revList.Add(rev);

                    }
                }
                dr.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                    con.Close();
            }
            return revList;
        }


    }

}

