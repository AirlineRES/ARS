﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Revenue.Exceptions;
using Revenue.Entities;
using Revenue.DAL;

namespace Revenue.BL
{
    public class RevenueBL
    {
        public static IEnumerable<Revenues> SelectAllBL()
        {
            IEnumerable<Revenues> revList = null;
            try
            {
                RevenueDAL revDAL = new RevenueDAL();
               // revList = revDAL.SelectAllDAL();
            }
            catch (RevenueException ex)
            {
                throw ex;
            }


            return revList;

        }

       
    }
}
