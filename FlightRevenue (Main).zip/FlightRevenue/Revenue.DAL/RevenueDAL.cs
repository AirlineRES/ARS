﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Revenue.Exceptions;
using System.Configuration;
using System.Data.SqlClient;
using Revenue.Entities;

namespace Revenue.DAL
{
    public class RevenueDAL
    {
        SqlConnection con = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public RevenueDAL()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["con1"].ConnectionString);

        }



        public IEnumerable<Revenues> TotalRevenueSpecifiedDAL(DateTime date1, DateTime date2)
        {
            List<Revenues> revList = new List<Revenues>();
            try
            {
                cmd = new SqlCommand("[Airline].[USP_Rev3]", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@date1", Convert.ToDateTime(date1));
                cmd.Parameters.AddWithValue("@date2", Convert.ToDateTime(date2));
                con.Open();

                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        Revenues reven = new Revenues();


                        reven.TotalSpecified = Convert.ToInt32(dr[0]);
                        //reven.Date2 = Convert.ToDateTime(dr[1]);
                        revList.Add(reven);

                    }
                }
                dr.Close();

            }
            catch (RevenueException ae)
            {
                throw ae;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                    con.Close();
            }
            return revList;
        }

        //public Revenues TotalRevenueSpecifiedDAL(DateTime date1,DateTime date2)
        //{
        //    Revenues rev = new Revenues();

        //    try
        //    {

        //        cmd = new SqlCommand("[airline].[USP_Rev3]", con);
        //        cmd.CommandType = System.Data.CommandType.StoredProcedure;
        //        cmd.Parameters.AddWithValue("@date1", Convert.ToDateTime(date1));
        //        cmd.Parameters.AddWithValue("@date2", Convert.ToDateTime(date2));
        //        con.Open();
        //        dr = cmd.ExecuteReader();
        //        if (dr.HasRows)
        //        {
        //            while (dr.Read())
        //            {

        //                rev.TotalSpecified = Convert.ToInt32(dr[0]);
        //                //rev.FareFirstClass = Convert.ToInt32(dr[1]);
        //                //rev.FareEconomyClass = Convert.ToInt32(dr[2]);
        //                //rev.NumberBusinessClass = Convert.ToInt32(dr[3]);
        //                //rev.NumberFirstClass = Convert.ToInt32(dr[4]);
        //                //rev.NumberEconomyClass = Convert.ToInt32(dr[5]);



        //            }
        //        }
        //        dr.Close();
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    finally
        //    {
        //        if (con.State == System.Data.ConnectionState.Open)
        //            con.Close();
        //    }
        //    return rev;
        //}

        public Revenues TotalRevenueDAL(int FlightID)
        {
            Revenues rev = new Revenues();

            try
            {

                cmd = new SqlCommand("[airline].[USP_Rev]", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@f_Id", FlightID);

                con.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {

                        rev.TotalRevenue = Convert.ToInt32(dr[0]);
                        //rev.FareFirstClass = Convert.ToInt32(dr[1]);
                        //rev.FareEconomyClass = Convert.ToInt32(dr[2]);
                        //rev.NumberBusinessClass = Convert.ToInt32(dr[3]);
                        //rev.NumberFirstClass = Convert.ToInt32(dr[4]);
                        //rev.NumberEconomyClass = Convert.ToInt32(dr[5]);



                    }
                }
                dr.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                    con.Close();
            }
            return rev;
        }

    }

}

