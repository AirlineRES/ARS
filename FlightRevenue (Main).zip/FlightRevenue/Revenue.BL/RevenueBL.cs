﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Revenue.Exceptions;
using Revenue.Entities;
using Revenue.DAL;

namespace Revenue.BL
{
    public class RevenueBL
    {
        
        public static IEnumerable<Revenues> TotalRevenueSpecifiedBL()
        {
            IEnumerable<Revenues> rev = null;
            try
            {
                RevenueDAL revDAL = new RevenueDAL();


            }
            catch(Exception ex)
            {
                throw ex;
            }
            return rev;
        }

        public static Revenues TotalRevenueBL(int fid)
        {
            Revenues rev = null;
            try
            {
                RevenueDAL revDAL = new RevenueDAL();
                rev = revDAL.TotalRevenueDAL(fid);
                // rev = revDAL.SelectAllDAL(fid);
            }
            catch (RevenueException ex)
            {
                throw ex;
            }


            return rev;

        }


    }


}
