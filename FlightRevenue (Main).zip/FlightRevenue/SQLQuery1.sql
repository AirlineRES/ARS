﻿

select * from [airline].[Flights];

select * from [airline].[Reservation];
select * from [airline].[FlightClass]

select * from [airline].[Users];




 









 create procedure [airline].[USP_Rev]
 @f_ID int
as
Begin

select  Sum(NoofTickets*TotalFare) as "Total Revenue" from [airline].[Reservation]  where Class IN('Business Class','Economy Class','First Class') AND FlightID = @f_ID ;

end

 create procedure [airline].[USP_Rev3]
 @date1 date,
 @date2 date
as
Begin

select  Sum(NoofTickets*TotalFare) as "Total Revenue" from [airline].[Reservation]  where JourneyDate Between @date1 and @date2 ;

end

exec [airline].[USP_Rev3] '2019/02/02','2019/05/05'

exec [airline].[USP_Rev] 109

drop  procedure [airline].[USP_Rev3] 

