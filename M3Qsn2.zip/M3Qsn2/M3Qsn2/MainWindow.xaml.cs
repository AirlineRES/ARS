﻿
// /<Summary>
/*********************************************************************
 * File                 : MainWindow.xaml.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to for GUI Design and doing the required query.
 * Version              : 1.0
 * Last Modified Date   : 14-Dec-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/
///</Summary>


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace M3Qsn2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Training_24Oct18_PuneEntities dbContext = null;
       
        public MainWindow()
        {
            InitializeComponent();
            dbContext = new Training_24Oct18_PuneEntities();
        }

        // Function to perform the respective query

        public void PopulateUI()
        {
            try
            {
                List<Customer> cust = dbContext.Customers.ToList();
                var res = cust.Where(s => s.CustCity == "mumbai" || s.CustCity == "Mumbai");

                txtCustomerGrid.ItemsSource = res;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

     
        // Function to show Populate the data into grid

        private void btnShow_Click(object sender, RoutedEventArgs e)
        {
            PopulateUI();
        }

       
    }
}
